# GameTimeLimiter
Upload this ZIP to GitHub and use the Actions workflow to build APK.