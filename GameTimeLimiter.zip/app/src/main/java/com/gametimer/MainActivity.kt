package com.gametimer

import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.os.Bundle
import android.os.CountDownTimer
import android.text.InputType
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AppCompatDelegate
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    // Timer variables
    private lateinit var timerText: TextView
    private lateinit var startBtn: Button
    private lateinit var pauseBtn: Button
    private lateinit var resetBtn: Button
    private lateinit var setBtn: Button
    private lateinit var changePassBtn: Button
    private lateinit var themeBtn: Button
    private lateinit var statusText: TextView
    private var countDownTimer: CountDownTimer? = null
    private var remainingMs: Long = 0L
    private var running = false
    private lateinit var prefs: SharedPreferences
    private val PREFS = "gamelimiter_prefs"
    private val KEY_PASS = "parent_pass"
    private val KEY_REMAIN = "remaining_ms"
    private val KEY_DATE = "saved_date"
    private val KEY_THEME = "theme_mode"
    private val DATE_FORMAT = "yyyy-MM-dd"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        timerText = findViewById(R.id.timerText)
        startBtn = findViewById(R.id.startBtn)
        pauseBtn = findViewById(R.id.pauseBtn)
        resetBtn = findViewById(R.id.resetBtn)
        setBtn = findViewById(R.id.setBtn)
        changePassBtn = findViewById(R.id.changePassBtn)
        themeBtn = findViewById(R.id.themeBtn)
        statusText = findViewById(R.id.statusText)

        val theme = prefs.getInt(KEY_THEME, AppCompatDelegate.MODE_NIGHT_YES)
        AppCompatDelegate.setDefaultNightMode(theme)
        themeBtn.text = if(theme==AppCompatDelegate.MODE_NIGHT_YES)"Theme: Dark" else "Theme: Light"

        startBtn.setOnClickListener{ requirePasswordThen{ startTimer() } }
        pauseBtn.setOnClickListener{ requirePasswordThen{ pauseTimer() } }
        resetBtn.setOnClickListener{ requirePasswordThen{ resetTimer() } }
        setBtn.setOnClickListener{ requirePasswordThen{ showSetTimeDialog() } }
        changePassBtn.setOnClickListener{ showChangePasswordDialog() }
        themeBtn.setOnClickListener{ toggleTheme() }
    }

    private fun startTimer(){ /* simplified timer start */ }
    private fun pauseTimer(){ /* simplified timer pause */ }
    private fun resetTimer(){ /* simplified timer reset */ }
    private fun showSetTimeDialog(){ /* simplified set timer dialog */ }
    private fun showChangePasswordDialog(){ /* simplified change password */ }
    private fun requirePasswordThen(action:()->Unit){ /* simplified password */ }
    private fun toggleTheme(){ val current=prefs.getInt(KEY_THEME,AppCompatDelegate.MODE_NIGHT_YES); val next=if(current==AppCompatDelegate.MODE_NIGHT_YES)AppCompatDelegate.MODE_NIGHT_NO else AppCompatDelegate.MODE_NIGHT_YES; prefs.edit().putInt(KEY_THEME,next).apply(); AppCompatDelegate.setDefaultNightMode(next); themeBtn.text=if(next==AppCompatDelegate.MODE_NIGHT_YES)"Theme: Dark" else "Theme: Light" }
}
